ancistrus

Netgear's D7000 Nighthawk Router Experience Distributed Project

https://github.com/negan07/ancistrus

License: GPLv2


This distributed project has the purpose of improving:

a) the embedded software developing experience;

b) the router performances, ability and reliability.

The word 'distributed' is to be intended with the same meaning of git developing system philosophy.
Interested people with up to tiny unix programming or www knowledge may offer his own contribute 
to this project with code, scripts, patches, fixes, methods, ideas, everything useful.

The approach is typical learn-to-learn oriented: feel free to join with your own contribution. 

